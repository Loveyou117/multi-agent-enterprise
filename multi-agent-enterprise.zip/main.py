from fastapi import FastAPI
from pydantic import BaseModel
from agents import marketing_agent,sales_agent,customer_agent,data_agent,report_agent
from scheduler import start_scheduler
import os
from dotenv import load_dotenv

load_dotenv()
app = FastAPI(title="Multi Agent Enterprise System")
start_scheduler()

class TaskRequest(BaseModel):
    task:str

@app.get("/")
def home():
    return {"msg":"running"}

@app.post("/run")
def run_task(req:TaskRequest):
    task=req.task
    marketing=marketing_agent(task)
    sales=sales_agent(task)
    customer=customer_agent(task)
    data=data_agent(task)
    final=report_agent(f"""任务:{task}

市场部结果：
{marketing}

销售部结果：
{sales}

客服部结果：
{customer}

数据部结果：
{data}

请整合输出最终企业执行方案""")
    return {
        "marketing":marketing,
        "sales":sales,
        "customer":customer,
        "data":data,
        "final":final
    }
