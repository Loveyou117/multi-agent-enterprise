import os
from openai import OpenAI

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def ask_gpt(role, task):
    prompt = f"""你现在是企业中的{role}

任务：
{task}

请输出专业、简洁、可执行的结果。"""
    res = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role":"user","content":prompt}]
    )
    return res.choices[0].message.content

def marketing_agent(task): return ask_gpt("市场运营总监", task)
def sales_agent(task): return ask_gpt("销售主管", task)
def customer_agent(task): return ask_gpt("客服经理", task)
def data_agent(task): return ask_gpt("数据分析师", task)
def report_agent(task): return ask_gpt("企业CEO助理", task)
