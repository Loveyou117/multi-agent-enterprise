from apscheduler.schedulers.background import BackgroundScheduler
from agents import report_agent

scheduler = BackgroundScheduler()

def daily_report():
    result = report_agent("整理今日市场、销售、客服、数据情况，输出一份企业运营日报")
    with open("daily_report.txt","w",encoding="utf8") as f:
        f.write(result)

def start_scheduler():
    scheduler.add_job(daily_report, "interval", hours=24)
    scheduler.start()
