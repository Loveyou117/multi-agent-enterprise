# Multi Agent Enterprise

## 安装
```bash
pip install -r requirements.txt
cp .env.example .env
# 编辑 .env 填入 OPENAI_API_KEY
uvicorn main:app --reload
```

## 访问
http://127.0.0.1:8000/docs

## 示例请求
POST /run

```json
{"task":"本月提升公司营收30%"}
```
